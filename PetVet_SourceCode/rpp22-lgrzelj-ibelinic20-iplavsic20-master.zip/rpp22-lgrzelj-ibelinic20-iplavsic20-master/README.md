# PetVet
![PetVet_Logo](https://user-images.githubusercontent.com/100703325/195669365-b96040d9-fe75-4c60-889c-c50b5cc2a8cb.PNG)

Aplikacija namijenjena praćenju aktivnosti ljubimca, ali i veterinara


## Projektni tim

Ime i prezime | E-mail adresa (FOI) | JMBAG | Github korisničko ime
------------  | ------------------- | ----- | ---------------------
Lucija Grzelj | lgrzelj@student.foi.hr | 0016145583 | lgrzelj
Ivana Belinić | ibelinic20@student.foi.hr | 0016147210 | ibelinic
Iva Plavšić | iplavsic20@student.foi.hr | 0016146806 | iplavsic20


## Opis domene
Problemska domena kojom će se ova Desktop aplikacija baviti bit će ponajprije praćenje zdravstvenog stanja ljubimca te radnih aktivnosti veterinara u virtualnom okruženju. Dokument će obuhvaćati određene specifikacije potrebne za implementiranje desktop aplikativnog rješenja u svrhu učinkovitijeg vođenja zdravstvenog života korisnikovog ljubimca u digitalnom obliku te radnih aktivnosti veterinara putem digitaliziranog kalendara aktivnosti. Naime, dokument prikazuje potrebne funkcionalnosti samog budućeg desktop aplikativnog rješenja koje bi trebale biti implementirane u isti pri čemu bi svaki sudionik kreiranja aplikacije bio upućen u potrebne modularnosti.

## Specifikacija projekta
Dokumentom se želi postići jasna i detaljna specifikacija korisnikovih zahtjeva na temelju kojih bi se implementirala sama desktop aplikacija. Desktop aplikativno rješenje trebalo bi moći ostvariti sve zahtjeve korisnika te osigurati potrebu za korištenjem istog, odnosno potrebu za digitaliziranim načinom upotrebe dosadašnjeg ručnog praćenja zdravstvenih obaveza ljubimca te radnih aktivnosti veterinara u obliku dokumentiranih prikaza. Ovim projektom digitalizirao bi se cjelokupni način praćenja zdravstvenog života ljubimca putem vlasnika i veterinara uz pomoć desktop aplikacije koja bi sadržavala bitne i potrebne podatke, ali i aktivnosti.
Buduća arhitektura programskog proizvoda Desktop aplikacije PetVet bit će višeslojna s odvojenom, odnosno dislociranom bazom podataka. Osnovu spomenute arhitekture predstavlja sustav koji nudi gotova rješenja i funkcionalnosti kako bi se ubrzao proces razvoja aplikacije.

Funkcionalnosti sustava:

Oznaka | Naziv | Kratki opis | Odgovorni član tima
------ | ----- | ----------- | -------------------
F01 | Registracija/prijava uz mogućnost odjave korisnika | Korisnik se treba registrirati ili prijaviti u aplikaciju kako bi imao pristup svim funkcionalnostima iste, također se može i odjaviti te prilikom prijave ima mogućnost promjene lozinke ukoliko je zaboravljena. | Lucija Grzelj
F02 | Izrada/brisanje profila | Korisnik ima mogućnost izrade profila vlastitim ljubimcima te ima i mogućnost brisanja istih. | Ivana Belinić
F03 | Digitalni karton | Korisnik u ulozi veterinara ima mogućnost otvaranja novog digitalnog kartona ljubimca. | Iva Plavšić
F04 | Popunjavanje rasporeda unutar kalendara |  Korisnik u ulozi veterinara ima mogućnost popunjavanja kaledara vlastitim aktivnostima prema rasporedu. | Lucija Grzelj
F05 | Pregled dostupnih veterinara unutar kalendara | Korisnik u ulozi vlasnika ima mogućnost pregleda slobodnih termina s obzirom na raspored veterinara. | Ivana Belinić
F06 | Prijava/odjava odabranog termina | Korisnik u ulozi vlasnika ima mogućnost odabira jednog od slobodnih termina unutar prikazanog kalendara te odjavu istog. | Iva Plavšić
F07 | Izrada izvještaja digitalnog kartona | Korisnik u obje uloge ima mogućnost izrade izvještaja digitalnog kartona ljubimaca. | Lucija Grzelj
F08 | Evidentiranje određenih tretmana kartona ljubimca | Korisnik u ulozi veterinara ima mogućnost popunjavanja digitalnog kartona o ljubimcima. | Ivana Belinić
F09 | Pretraživanje korisnika i njihovih ljubimaca | Korisnik u ulozi vlasnika ima mogućnost pretraživanja ostalih korisnika i njihovih ljubimaca. | Iva Plavšić

## Tehnologije i oprema
Tehnologije i opreme koje će se koristiti za implementaciju desktop aplikativnog rješenja su sljedeće: računalo, DBMS i SQL Server Management Studio za izradu baze podataka, Visual Studio za izradu programskog koda, git i GitHub za verzioniranje programskog koda, GitHub Wiki za pisanje tehničke i projektne dokumentacije, GitHub projects za planiranje i praćenje projektnih zadataka. Projekt će se razvijati koristeći .Net Framework razvojni okvir te vrstu projekta u WinForms obliku.
